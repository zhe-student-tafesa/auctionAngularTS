export interface ProductSearchParams {
  title:string;
  price: number;

  category:string;
}
